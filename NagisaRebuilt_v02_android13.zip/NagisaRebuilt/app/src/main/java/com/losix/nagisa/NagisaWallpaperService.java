package com.losix.nagisa;

import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Rect;
import java.io.InputStream;
import java.util.Calendar;

/** First-pass compatibility renderer. The original image/time tables are preserved in assets. */
public class NagisaWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new NagisaEngine(); }

    private class NagisaEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private Bitmap character, background;
        private int battery = 100;
        private boolean visible;
        private int touchExpression = 0;
        private float xOffset = 0.5f;
        private final Runnable drawTask = new Runnable() { @Override public void run() { drawFrame(); } };
        private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                int level = i.getIntExtra("level", 100);
                int scale = i.getIntExtra("scale", 100);
                battery = scale > 0 ? (level * 100 / scale) : 100;
                loadCharacter(); drawFrame();
            }
        };

        NagisaEngine() {
            setTouchEventsEnabled(true);
            IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent state = registerReceiver(batteryReceiver, f);
            if (state != null) {
                int l=state.getIntExtra("level",100), s=state.getIntExtra("scale",100);
                battery=s>0?l*100/s:100;
            }
            loadImages();
        }

        private String period() {
            Calendar c=Calendar.getInstance(); int h=c.get(Calendar.HOUR_OF_DAY);
            if(h>=5 && h<8) return "earlymorning";
            if(h>=8 && h<12) return "morning";
            if(h>=12 && h<16) return "noon";
            if(h>=16 && h<18) return "evening";
            if(h>=18 && h<20) return "night";
            if(h<22) return "midnight";
            return "midnight_2";
        }
        private String suffix() {
            String p=period();
            if(p.equals("evening")) return "b";
            if(p.equals("night") || p.equals("midnight")) return "c";
            return "a";
        }
        private String expression() {
            if (touchExpression > 0) return "n001" + suffix();
            if (battery >= 75) return "n001" + suffix();
            if (battery >= 50) return "n002" + suffix();
            if (battery >= 25) return "n003" + suffix();
            return "n004" + suffix();
        }
        private void loadImages() {
            loadCharacter();
            loadBackground();
        }
        private Bitmap assetBitmap(String path) {
            try (InputStream in=getAssets().open(path)) { return BitmapFactory.decodeStream(in); }
            catch(Exception e) { return null; }
        }
        private void loadCharacter() {
            Bitmap b=assetBitmap("image/nagisa/"+expression()+".png");
            if(b!=null) { if(character!=null) character.recycle(); character=b; }
        }
        private void loadBackground() {
            String p=period();
            String file;
            switch(p) {
                case "earlymorning": file="bg001.png"; break;
                case "morning": file="bg002.png"; break;
                case "noon": file="bg003.png"; break;
                case "evening": file="bg004.png"; break;
                case "night": file="bg005.png"; break;
                default: file="bg006.png"; break;
            }
            Bitmap b=assetBitmap("image/"+file);
            if(b!=null) { if(background!=null) background.recycle(); background=b; }
        }
        @Override public void onVisibilityChanged(boolean v) {
            visible=v; if(v) { loadImages(); handler.post(drawTask); } else handler.removeCallbacks(drawTask);
        }
        @Override public void onSurfaceChanged(SurfaceHolder h,int f,int w,int he) { super.onSurfaceChanged(h,f,w,he); drawFrame(); }
        @Override public void onSurfaceDestroyed(SurfaceHolder h) { visible=false; handler.removeCallbacks(drawTask); super.onSurfaceDestroyed(h); }
        @Override public void onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()==android.view.MotionEvent.ACTION_UP) { touchExpression=(touchExpression+1)%2; loadCharacter(); drawFrame(); }
            super.onTouchEvent(e);
        }
        private void drawFrame() {
            SurfaceHolder holder=getSurfaceHolder(); Canvas c=null;
            try {
                c=holder.lockCanvas(); if(c==null) return;
                int w=c.getWidth(), h=c.getHeight();
                c.drawColor(Color.rgb(35,35,45));
                if(background!=null) {
                    Rect src=new Rect(0,0,background.getWidth(),background.getHeight());
                    c.drawBitmap(background,src,new RectF(0,0,w,h),paint);
                }
                if(character!=null) {
                    float targetW=Math.min(w*0.82f, character.getWidth()*h/700f);
                    float scale=targetW/character.getWidth();
                    float dw=character.getWidth()*scale, dh=character.getHeight()*scale;
                    float left=(w-dw)/2f, top=h-dh;
                    c.drawBitmap(character,null,new RectF(left,top,left+dw,top+dh),paint);
                }
                Calendar now=Calendar.getInstance();
                paint.setColor(Color.WHITE); paint.setTextSize(Math.max(24f,w*0.055f)); paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
                paint.setShadowLayer(4f,1f,2f,Color.BLACK);
                String time=String.format(java.util.Locale.getDefault(),"%02d:%02d",now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE));
                c.drawText(time, w*0.06f, h*0.10f, paint);
                paint.clearShadowLayer();
            } catch(Exception ignored) { } finally { if(c!=null) holder.unlockCanvasAndPost(c); }
            handler.removeCallbacks(drawTask);
            if(visible) handler.postDelayed(drawTask, 60_000L);
        }
        @Override public void onDestroy() {
            handler.removeCallbacks(drawTask);
            try { unregisterReceiver(batteryReceiver); } catch(Exception ignored) { }
            if(character!=null) character.recycle(); if(background!=null) background.recycle();
            super.onDestroy();
        }
    }
}
