package com.losix.nagisa;

import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.view.MotionEvent;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.content.*;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Locale;

/** Compatibility renderer using the original Nagisa character and clock artwork. */
public class NagisaWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new NagisaEngine(); }

    private class NagisaEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private Bitmap character, background, analog1, analog2, digitalBase1, digitalLayer1, digitalBase2, digitalLayer2;
        private int battery = 100;
        private boolean visible;
        private SharedPreferences prefs;
        private final Runnable drawTask = new Runnable() { @Override public void run() { drawFrame(); } };
        private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                int level=i.getIntExtra("level",100), scale=i.getIntExtra("scale",100);
                battery=scale>0?level*100/scale:100; loadCharacter(); drawFrame();
            }
        };
        private final SharedPreferences.OnSharedPreferenceChangeListener prefListener = (p,k) -> drawFrame();

        NagisaEngine() {
            prefs=PreferenceManager.getDefaultSharedPreferences(NagisaWallpaperService.this);
            prefs.registerOnSharedPreferenceChangeListener(prefListener);
            Intent state=registerReceiver(batteryReceiver,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if(state!=null){int l=state.getIntExtra("level",100),s=state.getIntExtra("scale",100);battery=s>0?l*100/s:100;}
            loadImages();
        }
        private String period(){Calendar c=Calendar.getInstance();int h=c.get(Calendar.HOUR_OF_DAY);if(h>=5&&h<8)return"earlymorning";if(h>=8&&h<12)return"morning";if(h>=12&&h<16)return"noon";if(h>=16&&h<18)return"evening";if(h>=18&&h<20)return"night";if(h<22)return"midnight";return"midnight_2";}
        private String suffix(){String p=period();if(p.equals("evening"))return"b";if(p.equals("night")||p.equals("midnight"))return"c";return"a";}
        private String expression(){if(battery>=75)return"n001"+suffix();if(battery>=50)return"n002"+suffix();if(battery>=25)return"n003"+suffix();return"n004"+suffix();}
        private Bitmap assetBitmap(String path){try(InputStream in=getAssets().open(path)){return BitmapFactory.decodeStream(in);}catch(Exception e){return null;}}
        private void replaceCharacter(Bitmap b){if(b!=null){if(character!=null)character.recycle();character=b;}}
        private void loadCharacter(){replaceCharacter(assetBitmap("image/nagisa/"+expression()+".png"));}
        private void loadBackground(){String p=period(),file=p.equals("earlymorning")?"bg001.png":p.equals("morning")?"bg002.png":p.equals("noon")?"bg003.png":p.equals("evening")?"bg004.png":p.equals("night")?"bg005.png":"bg006.png";Bitmap b=assetBitmap("image/"+file);if(b!=null){if(background!=null)background.recycle();background=b;}}
        private void loadImages(){loadCharacter();loadBackground();if(analog1==null)analog1=assetBitmap("image/a001.png");if(analog2==null)analog2=assetBitmap("image/a002.png");if(digitalBase1==null)digitalBase1=assetBitmap("image/d001_2.png");if(digitalLayer1==null)digitalLayer1=assetBitmap("image/d001_1.png");if(digitalBase2==null)digitalBase2=assetBitmap("image/d002_2.png");if(digitalLayer2==null)digitalLayer2=assetBitmap("image/d002_1.png");}
        @Override public void onVisibilityChanged(boolean v){visible=v;if(v){loadImages();handler.post(drawTask);}else handler.removeCallbacks(drawTask);}
        @Override public void onSurfaceChanged(SurfaceHolder h,int f,int w,int he){super.onSurfaceChanged(h,f,w,he);drawFrame();}
        @Override public void onSurfaceDestroyed(SurfaceHolder h){visible=false;handler.removeCallbacks(drawTask);super.onSurfaceDestroyed(h);}
        // Touch is intentionally not used to change Nagisa's expression; battery level controls it.
        @Override public void onTouchEvent(MotionEvent e){super.onTouchEvent(e);}

        private int prefInt(String key,int def){return prefs.getInt(key,def);}
        private boolean prefBool(String key,boolean def){return prefs.getBoolean(key,def);}
        private void drawClock(Canvas c,int w,int h,Calendar now){
            int style=prefInt("clock_style",0), colorIndex=prefInt("clock_color",0);
            int color=colorIndex==1?Color.rgb(255,205,110):colorIndex==2?Color.rgb(115,220,255):Color.WHITE;
            float x=prefInt("clock_x",50)/100f*w, y=prefInt("clock_y",12)/100f*h;
            boolean seconds=prefBool("show_seconds",false), date=prefBool("show_date",true);
            if(style>=2){drawAnalog(c,w,h,now,style==2?analog1:analog2,x,y,color,seconds,date);return;}
            drawDigital(c,w,h,now,style,x,y,color,seconds,date);
        }

        private void drawDigital(Canvas c,int w,int h,Calendar now,int style,float cx,float top,int color,boolean seconds,boolean date){
            Bitmap base=style==0?digitalBase1:digitalBase2, layer=style==0?digitalLayer1:digitalLayer2;
            if(base==null||layer==null)return;
            String time=String.format(Locale.US,"%02d:%02d",now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE));
            float scale=Math.min(w*.00112f,h*.00078f);float digitW=60*scale,digitH=70*scale,colonW=32*scale;
            float total=digitW*4+colonW;float left=Math.max(5,Math.min(w-total-5,cx-total/2));
            float x=left;for(int i=0;i<time.length();i++){char ch=time.charAt(i);if(ch==':'){drawSprite(c,base,layer,new Rect(600,74,632,144),new RectF(x,top,x+colonW,top+digitH),color);x+=colonW;}else{int n=ch-'0';drawSprite(c,base,layer,new Rect(n*60,74,n*60+60,144),new RectF(x,top,x+digitW,top+digitH),color);x+=digitW;}}
            if(seconds){paint.setColor(color);paint.setTextSize(Math.max(13,w*.035f));paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));paint.setShadowLayer(3,1,1,Color.BLACK);String sec=String.format(Locale.US,"%02d",now.get(Calendar.SECOND));c.drawText(sec,Math.min(w-30,left+total+5),top+digitH*.85f,paint);paint.clearShadowLayer();}
            if(date){paint.setColor(color);paint.setTextSize(Math.max(12,w*.026f));paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));paint.setShadowLayer(3,1,1,Color.BLACK);String d=String.format(Locale.getDefault(),"%tA  %02d/%02d/%04d",now,now.get(Calendar.DAY_OF_MONTH),now.get(Calendar.MONTH)+1,now.get(Calendar.YEAR));float dw=paint.measureText(d);c.drawText(d,Math.max(5,Math.min(w-dw-5,cx-dw/2)),top+digitH+paint.getTextSize()+5,paint);paint.clearShadowLayer();}
        }
        private void drawSprite(Canvas c,Bitmap base,Bitmap layer,Rect src,RectF dst,int tint){
            paint.setColorFilter(null);c.drawBitmap(base,src,dst,paint);
            paint.setColorFilter(new PorterDuffColorFilter(tint,PorterDuff.Mode.MULTIPLY));c.drawBitmap(layer,src,dst,paint);paint.setColorFilter(null);
        }
        private void drawAnalog(Canvas c,int w,int h,Calendar now,Bitmap sheet,float cx,float cy,int color,boolean seconds,boolean date){
            if(sheet==null)return;
            boolean first=sheet==analog1;Rect face=first?new Rect(0,0,472,200):new Rect(0,0,132,132);
            float size=Math.min(w*.43f,h*.22f);float fw=first?size:size,fh=first?size*200f/472f:size;
            RectF dst=new RectF(cx-fw/2,cy,cx+fw/2,cy+fh);paint.setColor(Color.WHITE);c.drawBitmap(sheet,face,dst,paint);
            float dialX=first?dst.left+fw*(87f/472f):dst.left+fw*(65f/132f), dialY=first?dst.top+fh*(122f/200f):dst.top+fh*(65f/132f);
            float radius=fh*.31f;float hour=(now.get(Calendar.HOUR)+now.get(Calendar.MINUTE)/60f)*30f-90, minute=now.get(Calendar.MINUTE)*6f-90, sec=now.get(Calendar.SECOND)*6f-90;
            drawHand(c,dialX,dialY,radius*.55f,hour,4,color);drawHand(c,dialX,dialY,radius*.82f,minute,2.5f,color);if(seconds)drawHand(c,dialX,dialY,radius*.9f,sec,1.2f,Color.RED);
            paint.setColor(color);c.drawCircle(dialX,dialY,3,paint);
            if(date){paint.setTextSize(Math.max(12,w*.025f));paint.setShadowLayer(3,1,1,Color.BLACK);String d=String.format(Locale.getDefault(),"%02d/%02d  %tA",now.get(Calendar.DAY_OF_MONTH),now.get(Calendar.MONTH)+1,now);c.drawText(d,dst.left, dst.bottom+paint.getTextSize()+4,paint);paint.clearShadowLayer();}
        }
        private void drawHand(Canvas c,float x,float y,float len,float degrees,float width,int color){double a=Math.toRadians(degrees);paint.setColor(color);paint.setStrokeWidth(width);paint.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x,y,x+(float)Math.cos(a)*len,y+(float)Math.sin(a)*len,paint);}
        private void drawFrame(){SurfaceHolder holder=getSurfaceHolder();Canvas c=null;try{c=holder.lockCanvas();if(c==null)return;int w=c.getWidth(),h=c.getHeight();c.drawColor(Color.rgb(35,35,45));if(background!=null)c.drawBitmap(background,null,new RectF(0,0,w,h),paint);if(character!=null){float tw=Math.min(w*.82f,character.getWidth()*h/700f),sc=tw/character.getWidth(),dw=character.getWidth()*sc,dh=character.getHeight()*sc;c.drawBitmap(character,null,new RectF((w-dw)/2f,h-dh,(w+dw)/2f,h),paint);}drawClock(c,w,h,Calendar.getInstance());}catch(Exception ignored){}finally{if(c!=null)holder.unlockCanvasAndPost(c);}handler.removeCallbacks(drawTask);if(visible)handler.postDelayed(drawTask,prefBool("show_seconds",false)?1000L:15000L);}
        @Override public void onDestroy(){handler.removeCallbacks(drawTask);prefs.unregisterOnSharedPreferenceChangeListener(prefListener);try{unregisterReceiver(batteryReceiver);}catch(Exception ignored){}if(character!=null)character.recycle();if(background!=null)background.recycle();if(analog1!=null)analog1.recycle();if(analog2!=null)analog2.recycle();if(digitalBase1!=null)digitalBase1.recycle();if(digitalLayer1!=null)digitalLayer1.recycle();if(digitalBase2!=null)digitalBase2.recycle();if(digitalLayer2!=null)digitalLayer2.recycle();super.onDestroy();}
    }
}
