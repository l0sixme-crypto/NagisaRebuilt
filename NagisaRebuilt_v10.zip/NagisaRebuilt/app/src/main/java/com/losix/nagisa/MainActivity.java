package com.losix.nagisa;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/** Launcher and settings screen for the Nagisa live wallpaper. */
public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout root;
    private int pad;
    @Override protected void onCreate(Bundle state){super.onCreate(state);prefs=PreferenceManager.getDefaultSharedPreferences(this);pad=(int)(18*getResources().getDisplayMetrics().density);buildScreen();}
    private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(0,pad/2,0,pad/3);return t;}
    private void buildScreen(){
        ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(pad,pad,pad,pad);scroll.addView(root);
        TextView title=text("Nagisa Live Wallpaper",24);title.setGravity(Gravity.CENTER);title.setTypeface(null,Typeface.BOLD);root.addView(title);
        TextView intro=text("Wallpaper settings",16);intro.setGravity(Gravity.CENTER);root.addView(intro);
        addLabel("Clock");addSwitch("Show clock", "show_clock",true);
        addLabel("Clock design");String[] clocks={"Digital 1","Digital 2","Analog 1","Analog 2"};Spinner style=spinner(clocks);style.setSelection(prefs.getInt("clock_style",0));root.addView(style);style.setOnItemSelectedListener(new SimpleSelect(){public void selected(int p){prefs.edit().putInt("clock_style",p).apply();}});
        addLabel("Clock color (digital)");Spinner colors=spinner(new String[]{"White","Warm gold","Sky blue"});colors.setSelection(prefs.getInt("clock_color",0));root.addView(colors);colors.setOnItemSelectedListener(new SimpleSelect(){public void selected(int p){prefs.edit().putInt("clock_color",p).apply();}});
        addSeek("Clock size", "clock_size",100,25,200,"%");
        addLabel("Akio size");
        addSeek("Akio size", "akio_scale_percent_v2",200,30,400,"%");
        addSeek("Horizontal position", "clock_x",50,0,100,"%");addSeek("Vertical position", "clock_y",12,0,100,"%");
        addSwitch("Show seconds", "show_seconds",false);addSwitch("Show date and day", "show_date",true);
        Button preview=new Button(this);preview.setText("Preview / Set Nagisa wallpaper");root.addView(preview);preview.setOnClickListener(v->openWallpaperPreview());
        TextView note=text("Nagisa's expression changes with battery level. Fuko appears for one random five-minute period each day. Akio and Sanae appear on their scheduled calendar dates.",14);root.addView(note);
        setContentView(scroll);
    }
    private void addLabel(String s){root.addView(text(s,16));}
    private Spinner spinner(String[] values){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values);s.setAdapter(a);return s;}
    private abstract class SimpleSelect implements AdapterView.OnItemSelectedListener{public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int pos,long id){selected(pos);}public abstract void selected(int p);}
    private void addSwitch(String label,String key,boolean def){Switch sw=new Switch(this);sw.setText(label);sw.setTextSize(16);sw.setPadding(0,pad,0,pad);sw.setChecked(prefs.getBoolean(key,def));root.addView(sw);sw.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean(key,on).apply());}
    private void addSeek(String label,String key,int def,int min,int max,String suffix){addLabel(label);TextView value=text("",14);root.addView(value);SeekBar bar=new SeekBar(this);bar.setMax(max-min);int initial=Math.max(min,Math.min(max,prefs.getInt(key,def)));bar.setProgress(initial-min);value.setText(initial+suffix);root.addView(bar);bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean user){int v=p+min;value.setText(v+suffix);if(user)prefs.edit().putInt(key,v).apply();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});}
    private void openWallpaperPreview(){Intent i=new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,new ComponentName(this,NagisaWallpaperService.class));try{startActivity(i);}catch(Exception e){Toast.makeText(this,"Could not open wallpaper preview: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
}
